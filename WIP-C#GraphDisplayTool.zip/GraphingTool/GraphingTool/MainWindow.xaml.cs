﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

public class adjacencymatrix
{
    int n;
    char[,] matrix;

    public adjacencymatrix()
    {
        int n = 0;
        char[,] matrix = new char[1, 1];
    }

    public void setfromfile(string name)
    {
        string[] lines = System.IO.File.ReadAllLines(@"C:\Users\David B\Desktop\adjmat stuff\directed\AdjMatriRotation\" + name);

        n = lines[0].Length;

        char[,] adjmat = new char[n, n];

        for (int i = 0; i < n; i++)
        {
            for (int j = 0; j < n; j++)
            {
                adjmat[i, j] = lines[i][j];
            }
        }

        matrix = adjmat;
    }

    public int dimension()
    {
        return n;
    }

    public char[,] data()
    {
        return matrix;
    }
}

public class Node
{
    public Label label;
    public Canvas GraphCanvas;
    public Graph Graph;
    public Ellipse VisualEllipse;
    public System.Windows.Point NodeCenterPoint;
    public double NodeRadius = 25;

    public Node(System.Windows.Point GraphCenterPoint, double NodeDistanceFromGraphCenter, int NodeNumber, Graph Graph, Canvas GraphCanvas)
    {
        this.GraphCanvas = GraphCanvas;
        this.Graph = Graph;
        double fraction = NodeNumber / Graph.AdjacencyMatrix.dimension();

        NodeCenterPoint = new System.Windows.Point(GraphCenterPoint.X + Math.Cos(Math.PI/2 + 2 * Math.PI * NodeNumber / Graph.AdjacencyMatrix.dimension()) * NodeDistanceFromGraphCenter,
                                                   GraphCenterPoint.Y + Math.Sin(Math.PI/2 + 2 * Math.PI * NodeNumber / Graph.AdjacencyMatrix.dimension()) * NodeDistanceFromGraphCenter);

        label = new Label();
        label.Content = NodeNumber;
        label.FontSize = 20;


        VisualEllipse = new Ellipse();
        VisualEllipse.Stroke = System.Windows.Media.Brushes.Black;
        VisualEllipse.Fill = System.Windows.Media.Brushes.LightGray;
        VisualEllipse.Width = 2 * NodeRadius;
        VisualEllipse.Height = 2 * NodeRadius;
        VisualEllipse.StrokeThickness = 1;

        VisualEllipse.MouseEnter += new MouseEventHandler(MouseEnterResponse);
        VisualEllipse.MouseLeave += new MouseEventHandler(MouseLeaveResponse);
        VisualEllipse.MouseLeftButtonDown += new MouseButtonEventHandler(LeftClickNode);

        label.MouseEnter += new MouseEventHandler(labelmouseenter);
        label.MouseLeave += new MouseEventHandler (labelmouseleave);
        label.MouseLeftButtonDown += new MouseButtonEventHandler(LeftClicklabel);
    }

    private System.Windows.Point StartPos;
    private System.Windows.Point EndPos;

    private void labelmouseenter(object sender, MouseEventArgs e)
    {
        MouseEnterResponse(this.VisualEllipse, e);
    }

    private void labelmouseleave(object sender, MouseEventArgs e)
    {
        MouseLeaveResponse(this.VisualEllipse, e);
    }

    private void LeftClicklabel(object sender, MouseButtonEventArgs e)
    {
        LeftClickNode(this.VisualEllipse, e);
    }


    private void LeftClickNode(object sender, MouseButtonEventArgs e)
    {
        StartPos = e.GetPosition(GraphCanvas);
        Ellipse MoveWindow = new Ellipse();
        MoveWindow.Stroke = System.Windows.Media.Brushes.Black;
        MoveWindow.StrokeThickness = 2;
        MoveWindow.Fill = System.Windows.Media.Brushes.DarkGray;
        MoveWindow.Opacity = 0;
        MoveWindow.Width = 500;
        MoveWindow.Height = 500;
        MoveWindow.MouseLeftButtonUp += new MouseButtonEventHandler(LMBReleaseInWindow);
        MoveWindow.MouseEnter += new MouseEventHandler(MouseEnterWindow);
        MoveWindow.MouseLeave += new MouseEventHandler(MouseLeaveWindow);
        GraphCanvas.Children.Add(MoveWindow);

    }

    private void MouseLeaveWindow(object sender, MouseEventArgs e)
    {
        if (e.LeftButton == MouseButtonState.Pressed)
        {
            this.VisualEllipse.Fill = System.Windows.Media.Brushes.LightGray;
            GraphCanvas.Children.Remove(sender as Ellipse);
        }
    }

    private void MouseEnterWindow(object sender, MouseEventArgs e)
    {
        this.VisualEllipse.Fill = System.Windows.Media.Brushes.AliceBlue;
    }

    private void  LMBReleaseInWindow(object sender, MouseButtonEventArgs e)
    {
        EndPos = e.GetPosition(GraphCanvas);
        double DeltaX = (EndPos.X - StartPos.X);
        double DeltaY = (EndPos.Y - StartPos.Y);

        NodeCenterPoint.X += DeltaX;
        NodeCenterPoint.Y += DeltaY;

        GraphCanvas.Children.Clear();
        Graph.DrawNewGraph();
    }

    private void MouseEnterResponse(object sender, MouseEventArgs e)
    {
        (sender as Ellipse).Fill = System.Windows.Media.Brushes.AliceBlue;
    }

    private void MouseLeaveResponse(object sender, MouseEventArgs e)
    {
        (sender as Ellipse).Fill = System.Windows.Media.Brushes.LightGray;
    }
}

public class Edge
{
    public Line VisualLine;
    public Line VisualOutline;
    public Line DirectionIndicator;

    public Edge(Node StartNode, Node EndNode)
    {
        VisualLine = new Line();
        VisualLine.Stroke = System.Windows.Media.Brushes.LightGray;
        VisualLine.X1 = StartNode.NodeCenterPoint.X;
        VisualLine.Y1 = StartNode.NodeCenterPoint.Y;
        VisualLine.X2 = EndNode.NodeCenterPoint.X;
        VisualLine.Y2 = EndNode.NodeCenterPoint.Y;
        VisualLine.StrokeThickness = 10;

        VisualOutline = new Line();
        VisualOutline.Stroke = System.Windows.Media.Brushes.Black;
        VisualOutline.X1 = StartNode.NodeCenterPoint.X;
        VisualOutline.Y1 = StartNode.NodeCenterPoint.Y;
        VisualOutline.X2 = EndNode.NodeCenterPoint.X;
        VisualOutline.Y2 = EndNode.NodeCenterPoint.Y;
        VisualOutline.StrokeThickness = 12;

        double m = (EndNode.NodeCenterPoint.Y - StartNode.NodeCenterPoint.Y) / (EndNode.NodeCenterPoint.X - StartNode.NodeCenterPoint.X);
        double theta = Math.Atan(m);

        DirectionIndicator = new Line();
        DirectionIndicator.Stroke = System.Windows.Media.Brushes.Black;
        DirectionIndicator.StrokeThickness = 1.5;

        if (EndNode.NodeCenterPoint.X < StartNode.NodeCenterPoint.X)
        {
            DirectionIndicator.X1 = EndNode.NodeCenterPoint.X + 1.5 * EndNode.NodeRadius * Math.Cos(theta);
            DirectionIndicator.Y1 = EndNode.NodeCenterPoint.Y + 1.5 * EndNode.NodeRadius * Math.Sin(theta);
            DirectionIndicator.X2 = EndNode.NodeCenterPoint.X + EndNode.NodeRadius * Math.Cos(theta);
            DirectionIndicator.Y2 = EndNode.NodeCenterPoint.Y + EndNode.NodeRadius * Math.Sin(theta);
        }

        if (EndNode.NodeCenterPoint.X > StartNode.NodeCenterPoint.X)
        {
            DirectionIndicator.X1 = EndNode.NodeCenterPoint.X - 1.5 * EndNode.NodeRadius * Math.Cos(theta);
            DirectionIndicator.Y1 = EndNode.NodeCenterPoint.Y - 1.5 * EndNode.NodeRadius * Math.Sin(theta);
            DirectionIndicator.X2 = EndNode.NodeCenterPoint.X - EndNode.NodeRadius * Math.Cos(theta);
            DirectionIndicator.Y2 = EndNode.NodeCenterPoint.Y - EndNode.NodeRadius * Math.Sin(theta);
        }

    }
}

public class Graph
{
    public adjacencymatrix AdjacencyMatrix;
    public Canvas GraphCanvas;
    public System.Windows.Point GraphCenterPoint;
    public double NodeDistanceFromGraphCenter = 150;
    public Node[] VertexSet;
    public Edge[,] EdgeSet;

    public Graph(double GraphCenterX, double GraphCenterY, Canvas GraphCanvas)
    {
        this.GraphCanvas = GraphCanvas;

        AdjacencyMatrix = new adjacencymatrix();
        AdjacencyMatrix.setfromfile("7uniquefile60.txt");

        GraphCenterPoint.X = GraphCenterX;
        GraphCenterPoint.Y = GraphCenterY;

        VertexSet = new Node[AdjacencyMatrix.dimension()];
        EdgeSet = new Edge[AdjacencyMatrix.dimension(), AdjacencyMatrix.dimension()];

        for(int i = 0; i < AdjacencyMatrix.dimension(); i++)
            VertexSet[i] = new Node(GraphCenterPoint, NodeDistanceFromGraphCenter, i, this, GraphCanvas);

        for (int i = 0; i < AdjacencyMatrix.dimension(); i++)
        {
            for (int j = 0; j < AdjacencyMatrix.dimension(); j++)
            {
                if (AdjacencyMatrix.data()[i, j] == '1')
                {
                    EdgeSet[i, j] = new Edge(VertexSet[i],VertexSet[j]);
                }
            }
        }
    }

    public void DrawNewGraph()
    {

        // rotatation guy
        Ellipse RotateEllipse = new Ellipse();

        RotateEllipse.Fill = System.Windows.Media.Brushes.White;
        RotateEllipse.Width = 300;
        RotateEllipse.Height = 300;

        GraphCanvas.Children.Add(RotateEllipse);
        Canvas.SetTop(RotateEllipse,GraphCenterPoint.Y - 150);
        Canvas.SetLeft(RotateEllipse, GraphCenterPoint.X - 150);

        // outlines
        for (int i = 0; i < AdjacencyMatrix.dimension(); i++)
        {
            for (int j = 0; j < AdjacencyMatrix.dimension(); j++)
            {
                if (AdjacencyMatrix.data()[i, j] == '1')
                {
                    EdgeSet[i, j] = new Edge(VertexSet[i], VertexSet[j]);
                    GraphCanvas.Children.Add(EdgeSet[i, j].VisualOutline);
                }
            }
        }

        // edges
        for (int i = 0; i < AdjacencyMatrix.dimension(); i++)
        {
            for (int j = 0; j < AdjacencyMatrix.dimension(); j++)
            {
                if (AdjacencyMatrix.data()[i, j] == '1')
                {
                      //  GraphCanvas.Children.Add(EdgeSet[i, j].VisualOutline);
                    
                    GraphCanvas.Children.Add(EdgeSet[i, j].VisualLine);
                    GraphCanvas.Children.Add(EdgeSet[i, j].DirectionIndicator);
                }
            }
        }

        // ellipse
        for (int i = 0; i < AdjacencyMatrix.dimension(); i++)
        {
            GraphCanvas.Children.Add(VertexSet[i].VisualEllipse);
            Canvas.SetTop(VertexSet[i].VisualEllipse, VertexSet[i].NodeCenterPoint.Y - VertexSet[i].NodeRadius);
            Canvas.SetLeft(VertexSet[i].VisualEllipse, VertexSet[i].NodeCenterPoint.X - VertexSet[i].NodeRadius);

            GraphCanvas.Children.Add(VertexSet[i].label);
            Canvas.SetTop(VertexSet[i].label, VertexSet[i].NodeCenterPoint.Y - VertexSet[i].NodeRadius);
            Canvas.SetLeft(VertexSet[i].label, VertexSet[i].NodeCenterPoint.X - VertexSet[i].NodeRadius);

        }
    }


}

namespace GraphingTool
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            GraphCanvas.RenderTransform = new RotateTransform();
            (GraphCanvas.RenderTransform as RotateTransform).CenterX = this.Width / 2;
            (GraphCanvas.RenderTransform as RotateTransform).CenterY = this.Height / 2;

            Graph CurrentGraph = new Graph(this.Width/2,this.Height/2, GraphCanvas);
            CurrentGraph.DrawNewGraph();
        }


        private void GraphCanvas_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            (GraphCanvas.RenderTransform as RotateTransform).Angle += e.Delta / 30;
        }
    }
}
