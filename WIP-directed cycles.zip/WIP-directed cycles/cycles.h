#pragma once
#include "adjacencymatrix.h"
#include <algorithm>
#include <vector>
#include <fstream>
#include <string>

// fn for a given starting graph, check each of its rotations and each of its rotations' reflections until encountering one that is equal
bool isnew(adjacencymatrix matrix, std::vector<adjacencymatrix>& list) {

	for (int i = 0; i < matrix.dimension(); ++i) { // check the n-1 rotations

		if (std::find(list.begin(), list.end(), matrix) != list.end()) // check base
			return false;

		matrix.reflect();					 // check the reflection

		if (std::find(list.begin(), list.end(), matrix) != list.end())
			return false;

		matrix.reflect();					// reflect back, NEW TO DIRECTED
		matrix.rotate();					 // rotate
	}
	return true;
}

using cycle = std::vector<int>;
adjacencymatrix cycletomatrix(const cycle& c) {

	adjacencymatrix temp(c.size());

	for (int i = 0; i < c.size(); ++i) {

		temp.data()[c[i]][c[(i + 1)%c.size()]] = 1;
		//temp.data()[c[(i + 1) % c.size()]][c[i]] = 1;  // DONT NEED THIS ONE FOR DIRECTEDS
	}
	return temp;
}


int countuniques(int order) {
	
	//std::cout << "Working";

	//std::ofstream davidfile;
	//davidfile.open("davidfile.txt");

	//unsigned int count = 0;
	std::vector<adjacencymatrix> uniques;
	cycle base;

	for (int i = 0; i < order; ++i) {
		base.push_back(i);
	}

	do {
		//for (auto i : base) {
		//	std::cout << i << ' ';
		//}
		//std::cout << "\n";

		//count++;
		//if (count % 1000 == 0)
		//	std::cout << '.';

		//if (count % 3000 == 0)
		//	std::cout << "\b\b\b   \b\b\b";


		adjacencymatrix temp = cycletomatrix(base);
		//std::cout << "\n";
		//temp.print();

		if (isnew(temp, uniques)) {
			uniques.push_back(temp);
			//std::cout << "^unique" << "\n\n";
			//for (auto i : base) {               // this chunk prints out first encountered unique cycles
			//	//davidfile << i << ' ';
			//	std::cout << i << ' ';
			//}
			////davidfile << "\n";
			//std::cout << "\n";
			//temp.print();
		}
		
	} while (std::next_permutation(base.begin() + 1, base.end()));

	//davidfile.close();

	return uniques.size();
}

int printuniquefiles(int order) {

	std::string current = "";

	std::vector<adjacencymatrix> uniques;
	cycle base;

	for (int i = 0; i < order; ++i)
		base.push_back(i);

	int count = 0;

	do {
		current += "7uniquefile";
		current +=  std::to_string(count);
		current += ".txt";

		adjacencymatrix temp = cycletomatrix(base);

		if (isnew(temp, uniques)) {
			uniques.push_back(temp);
			for (auto i : base)           
				std::cout << i << ' ';
			
			std::cout << "\n";

			temp.printtofile(current);
			count++;
		}

		current.clear();

	} while (std::next_permutation(base.begin() + 1, base.end()));

	//davidfile.close();

	return uniques.size();
}