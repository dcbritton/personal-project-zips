#include "adjacencymatrix.h"
#include "cycles.h"
#include "genUniquesVec.h"

int main() {
	
	for (int i = 1; i < 11; i++)
		std::cout << countuniques(i) << "\n";

	//std::cout << "\n" << printuniquefiles(7) << "\n";

	//adjacencymatrix adjmat = cycletomatrix({ 0, 3, 2, 1, 6, 5, 4 });
	//adjmat.printtofile();


	return 0;
}