#pragma once
#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>

class adjacencymatrix {
private:

	int n = 0;
	bool** matrix = nullptr;

public:

	adjacencymatrix() {
		int n = 0;
		bool** matrix = nullptr;
	}

	adjacencymatrix(int n) {
		this->n = n;
		matrix = new bool* [n];

		for (int i = 0; i < n; ++i) {
			matrix[i] = new bool[n];
		}

		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				matrix[i][j] = 0;
			}
		}
	}

	adjacencymatrix(const adjacencymatrix& other) {
		n = other.n;
		matrix = new bool* [n];
		for (int i = 0; i < n; ++i) {
			matrix[i] = new bool[n];
		}

		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				matrix[i][j] = other.matrix[i][j];
			}
		}
	}

	~adjacencymatrix() {
		for (int i = 0; i < n; ++i) {
			delete[] matrix[i];
		}
		delete[] matrix;
	}

	void rotate() {

		bool* tempptr;
		tempptr = matrix[n - 1];

		for (int i = n - 1; i > 0; --i) {
			matrix[i] = matrix[i - 1];
		}
		matrix[0] = tempptr;

		bool temp;
		for (int i = 0; i < n; ++i) {
			temp = matrix[i][n - 1];
			for (int j = n - 1; j > 0; --j) {
				matrix[i][j] = matrix[i][j - 1];
			}
			matrix[i][0] = temp;
		}
	}

	void reflect() {

		adjacencymatrix temp = *this;

		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				matrix[i][j] = temp.matrix[n - 1 - j][n - 1 - i];
			}
		}
	}

	void reverse() {

		adjacencymatrix temp = *this;

		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				matrix[i][j] = temp.matrix[j][i];
			}
		}
	}

	bool** data() {
		return matrix;
	}

	int dimension() {
		return n;
	}

	void print() {
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				std::cout << matrix[i][j] << ' ';
			}
			std::cout << "\n";
		}
		std::cout << "\n";
	}

	void printtofile(std::string filename) {
		std::ofstream of;
		of.open(filename);
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				of << matrix[i][j];
			}
			of << "\n";
		}
		of.close();
	}

	bool operator==(const adjacencymatrix& other) {
		for (int i = 0; i < n; ++i) {
			//for (int j = i + 1; j < n; ++j) {	// OLD. THIS IS FOR UNDIRECTED ONLY: only need to check top half of matrix (j = i + 1)
			for (int j = 0; j < n; ++j) {       // NEW. must check the whole matrix for directed cycles. more comparisons
				if (matrix[i][j] != other.matrix[i][j]) {
					return false;
				}
			}
		}
		return true;
	}


};