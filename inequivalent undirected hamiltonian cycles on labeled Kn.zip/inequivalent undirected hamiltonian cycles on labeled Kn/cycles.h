#pragma once
#include "adjacencymatrix.h"
#include <algorithm>
#include <vector>
#include <fstream>

using cycle = std::vector<int>;
adjacencymatrix cycletomatrix(const cycle& c) {

	adjacencymatrix temp(c.size());

	for (int i = 0; i < c.size(); ++i) {

		temp.data()[c[i]][c[(i + 1)%c.size()]] = 1;
		temp.data()[c[(i + 1) % c.size()]][c[i]] = 1;
	}
	return temp;
}


int countuniques(int order) {
	
	//std::cout << "Working";

	//std::ofstream davidfile;
	//davidfile.open("davidfile.txt");

	//unsigned int count = 0;'

	std::vector<adjacencymatrix> uniques;
	cycle base;

	for (int i = 0; i < order; ++i) {
		base.push_back(i);
	}

	do {
		//for (auto i : base) {
		//	std::cout << i << ' ';
		//}
		//std::cout << "\n";

		//count++;
		//if (count % 1000 == 0)
		//	std::cout << '.';

		//if (count % 3000 == 0)
		//	std::cout << "\b\b\b   \b\b\b";


		adjacencymatrix temp = cycletomatrix(base);
		//std::cout << "\n";
		//temp.print();

		if (isnew(temp, uniques)) {
			uniques.push_back(temp);

			//print only unique cycles
			//std::cout << "unique" << "\n";
			for (auto i : base) {
				//davidfile << i << ' ';
				std::cout << i << ' ';
			}
			std::cout << '\n';

			////davidfile << "\n";
			//std::cout << "\n";
			//temp.print();
		}
	} while (std::next_permutation(base.begin() + 1, base.end()));

	//davidfile.close();

	return uniques.size();
}