#pragma once
#include "adjacencymatrix.h"
#include "cycles.h"
#include <algorithm>
#include <vector>


std::vector<adjacencymatrix> generateUniquesVector(int order) {

	//std::cout << "Working";

	std::vector<adjacencymatrix> uniques;
	cycle base;

	for (int i = 0; i < order; ++i) {
		base.push_back(i);
	}

	do {
		adjacencymatrix temp = cycletomatrix(base);

		if (isnew(temp, uniques)) {
			uniques.push_back(temp);
		}
	} while (std::next_permutation(base.begin() + 1, base.end()));

	return uniques;
}

adjacencymatrix findCongruentMatrix(adjacencymatrix matrix, std::vector<adjacencymatrix>& list) {

	for (int i = 0; i < matrix.dimension(); ++i) { // check the n-1 rotations

		if (std::find(list.begin(), list.end(), matrix) != list.end()) // check base
			return *(std::find(list.begin(), list.end(), matrix));

		matrix.reflect();					 // check the reflection

		if (std::find(list.begin(), list.end(), matrix) != list.end())
			return *(std::find(list.begin(), list.end(), matrix));

		matrix.reflect();					// reflect back
		matrix.rotate();					 // rotate
	}
	return 0;
}