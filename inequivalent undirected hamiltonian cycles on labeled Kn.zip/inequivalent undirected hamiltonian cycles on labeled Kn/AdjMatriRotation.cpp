#include "adjacencymatrix.h"
#include "cycles.h"
#include "genUniquesVec.h"

int main() {
	
	//for (int i = 1; i <= 10; i++) {
	//	std::cout << countuniques(i) << "\n";
	//}

	std::cout << countuniques(9) << "\n";

	//std::cout << "\n" << countuniques(6);

	//adjacencymatrix adjmat = cycletomatrix({ 0, 1, 3, 5, 4, 2 });
	//adjmat.print();
	// 
	//adjmat.printtofile();

	return 0;
}